fun main(){
    var a=0
    var b=0
    var c=0
    when{
        a <15 -> b=20
        b>40 -> c=100
        c==100 -> a=0

    }
    println(a)
}