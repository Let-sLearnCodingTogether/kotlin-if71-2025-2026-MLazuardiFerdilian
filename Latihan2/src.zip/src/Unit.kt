fun printMessage (message : String):Unit {
    println(message)
}
fun main(){
    printMessage("Hello Kotlin")
}