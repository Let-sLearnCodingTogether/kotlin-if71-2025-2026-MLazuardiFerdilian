fun main(){
    var sum = 1

    while(true){
        println("Sum: $sum")
        if(sum>=10) {
            break
        }
        sum++
    }
}