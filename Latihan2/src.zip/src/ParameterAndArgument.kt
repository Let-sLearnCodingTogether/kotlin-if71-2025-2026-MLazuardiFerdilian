fun greeting(name : String){
    println("Welcome $name")
}
fun main(){
    greeting("User 1")
}