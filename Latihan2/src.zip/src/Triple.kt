fun main()
{
    val firstUser : Triple<String, Int, Boolean> = Triple("user 1",20 , true)
    println(firstUser.first)
    println(firstUser.second)
    println(firstUser.third)
}