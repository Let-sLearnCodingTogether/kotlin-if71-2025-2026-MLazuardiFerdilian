fun main()
{
    val nilaiA =20
    val nilaiB =15

    val apakahLebihBesar = nilaiA > nilaiB
    println(apakahLebihBesar)

    val apakahSama = nilaiA == nilaiB
    println(apakahSama)


    val apakahTidakSama = nilaiA != nilaiB
    println(apakahTidakSama)

    println("apel"<"Kacang")
}