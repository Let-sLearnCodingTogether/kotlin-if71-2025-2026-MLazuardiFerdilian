fun main(){
    val range = 0..1000
    val rangeChar ='a'..'o'
    val rangeUntil = 1 until 10
    val rangeDownTo = 10 downTo 0


}