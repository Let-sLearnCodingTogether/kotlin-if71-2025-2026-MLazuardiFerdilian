fun main (){
    var num : Int = 10

    num +=1
    num -=1
    num *=2
    num /=2
    num %=3

    println(num)
}