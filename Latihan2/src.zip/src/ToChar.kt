fun main () {
    val myInt : Int = 65
    val myChar : Char = myInt.toChar()
    println(myInt)

    val myInt2 : Int = 36
    val myChar2 : Char = myChar.toChar()
    println(myInt2)
}