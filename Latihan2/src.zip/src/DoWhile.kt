fun main(){
    var i = 0

     do{

        print("Do $i")
        i++
    }while (i < 10)
}