fun main(){
    val finalExam : Float =90.88F

    if(finalExam > 90){
        println("Anda Lulus Kelas Kotlin")
    }else if(finalExam >80){
        println("Mungkin bisa lulus")
    }else{
        println("Tidak Lulus")
    }
}