fun main () {
    val myBoolean : Boolean = true
    val myBoolean2: Boolean = false
    println(myBoolean)
}