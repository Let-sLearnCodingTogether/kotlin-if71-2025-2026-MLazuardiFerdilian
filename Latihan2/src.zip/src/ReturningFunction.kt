fun felloFunction(){
    println("Fello function")
}
fun Function1(){
    println(felloFunction())
}
fun main(){
    helloFunction()
    Function1()
}