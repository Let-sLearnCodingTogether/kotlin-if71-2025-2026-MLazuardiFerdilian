fun main(){
    val address :String = """
        Jln.Rajawali
        Sumatera Selatan
        Palembang
        """.trimIndent()
    println(address)
}