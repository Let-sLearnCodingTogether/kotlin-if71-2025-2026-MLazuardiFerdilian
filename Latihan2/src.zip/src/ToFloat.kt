fun main () {
    val myDouble : Double = 1234.5678915455
    val myFloat : Float = myDouble.toFloat()

    println(myDouble)
}