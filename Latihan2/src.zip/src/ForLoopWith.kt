fun main(){
    val ages =10..9

    for (age in ages){
        println("Age $age")
    }
    for(age in 12..20){
        println("Age $age")
    }
}