fun main()
{
    val result1 : Int = 10 + 2
    val result2 : Int = 11 - 1
    val result3 : Int = 10 * 2
    val result4 : Int = 6 / 2
    val result5 : Int = 30 % 2

}