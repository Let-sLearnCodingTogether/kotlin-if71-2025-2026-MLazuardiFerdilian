fun main()
{
    val a = 5
    val b = -a
    val c = +a

    var x = 10
    println(x++)
    println(++x)
    println(x--)
    println(--x)

    val isTrue = false
    val result =!isTrue
}