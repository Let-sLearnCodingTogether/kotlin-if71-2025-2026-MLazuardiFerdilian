fun main() {
    val myChar : Char = 'a'
    println(myChar)
}