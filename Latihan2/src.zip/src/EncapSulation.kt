fun main(){
    val finalExam = 90

    if(finalExam >=80){
        val newFinalExam = finalExam + 10

        println(newFinalExam)
    }
//    println(newFinalExam)
}