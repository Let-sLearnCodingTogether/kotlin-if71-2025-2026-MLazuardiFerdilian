fun helloFunction(){
    println("Hello Function")
}
fun main(){
    helloFunction()
}