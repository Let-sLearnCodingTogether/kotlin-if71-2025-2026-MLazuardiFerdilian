fun main() {
    val nama : String = "M Lazuardi Ferdilian"
    val npm : String  = "2226250031"
    var age : Int = 0
    age=21

    println("nama" + npm+"dengan nama :"+nama+"memiliki usia"+age)

}