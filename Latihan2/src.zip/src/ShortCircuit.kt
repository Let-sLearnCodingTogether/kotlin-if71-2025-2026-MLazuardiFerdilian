fun main(){
    val isLonggetIn = false

    if(isLonggetIn && (5/0 == 0)){
        println("User has Access")
    }else{
        println("Access denied")
    }
}