//fun main () {
//    val myDouble : Double = 99.98
//    val myDo
//}