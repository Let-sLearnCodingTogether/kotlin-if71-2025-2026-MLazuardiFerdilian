fun main () {
    val university :String = " Universitas Multi Data Palembang"
    val address :String = """
        Jln.Rajawali
        Sumatera Selatan
        Palembang
        """.trimMargin()
    println(address)
}