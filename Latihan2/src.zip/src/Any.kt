fun main() {
    val example1 : Any = "Lz Zhu"
    val example2 : Any = 1
    val example3 : Any = false
    val example4 : Any = 3.14

    println(example1)
}