fun main(){
    var i = 0

    while (i <= 10) {
        print("While $i")
        i++
    }
}