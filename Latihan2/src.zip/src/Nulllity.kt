fun main(){
    //null
    var student :String = "Budi"
    println(student)
    //student =null

    var prodiIf :String? = null
    prodiIf = null
    println(prodiIf?.length)


}