fun main()
{
    val users : Array <String> = arrayOf("user1", "user2", "user3")

    for(user in users){
    println(user)
    }
}
