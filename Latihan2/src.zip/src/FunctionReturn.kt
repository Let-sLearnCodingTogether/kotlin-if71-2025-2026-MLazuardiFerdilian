fun sum(firstNumber: Int, secondNumber: Int): Int {
    return firstNumber + secondNumber
}

fun main(){
    println("Sum Result :${sum(1, 2)}")
    val a=sum(5,10)
    println(a)
}