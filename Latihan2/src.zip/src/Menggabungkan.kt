fun main() {
    val kelas = "Kotlin"
    val jumlahMahasiswa =  28

    println("kelas" + kelas+"berjumlah"+jumlahMahasiswa+1+"orang")
}